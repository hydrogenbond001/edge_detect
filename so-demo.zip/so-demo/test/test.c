#include "example.h"



int main() {

	    hello("Docker");

	        return 0;

}


