#ifndef EXAMPLE_H

#define EXAMPLE_H



void hello(const char* name);



#endif


